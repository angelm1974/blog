export interface Czlowiek {
  id: number;
  nazwisko: string;
  umiejetnosc: string;
  wiek: number;
  obraz: string;
}
